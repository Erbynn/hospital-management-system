/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Chashika
 */
public class Doctor extends Employee {
    String DocType;
    
   

    
    public Doctor(int EmpID,String Name,String BDay,String ContacNmbr,String Address,String AdmisnDate,String DocType){
        super( EmpID,Name,BDay,ContacNmbr,Address,AdmisnDate);
        this.DocType = DocType;
        
    }
    
}
