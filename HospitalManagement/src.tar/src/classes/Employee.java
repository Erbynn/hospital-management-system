/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Chashika
 */
public class Employee {
    private int EmpID;
    private String Name;
    private String BDay;
    private String ContacNmbr;
    private String Address;
    private String AdmisnDate;
    
    public Employee(int EmpID,String Name,String BDay,String ContacNmbr,String Address,String AdmisnDate){
        this.EmpID = EmpID;
        this.Name = Name;
        this.BDay = BDay;
        this.ContacNmbr = ContacNmbr;
        this.Address = Address;
        this.AdmisnDate = AdmisnDate;
    }

    /**
     * @return the EmpID
     */
    public int getEmpID() {
        return EmpID;
    }

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @return the BDay
     */
    public String getBDay() {
        return BDay;
    }

    /**
     * @return the ContacNmbr
     */
    public String getContacNmbr() {
        return ContacNmbr;
    }

    /**
     * @return the Address
     */
    public String getAddress() {
        return Address;
    }

    /**
     * @return the AdmisnDate
     */
    public String getAdmisnDate() {
        return AdmisnDate;
    }
    
}
