/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author Chashika
 */
class tst{
	public static void main(String args[]){
		cat c = new cat("sira","6","yellow",14);
		c.getall();
	}
}

class animal{
	String name, age;

	animal(String name,String age){
		this.name = name;
		this.age = age;
	}

	void getall(){
		System.out.println(name);
		System.out.println(age);
	}
}

class cat extends animal{
	String color;
	int size; 

	cat(String name,String age,String color,int size){
		super(name,age);
		this.color = color;
		this.size = size;
	}

	void getall(){super.getall();
		System.out.println(color);
		System.out.println(size);
	}
}