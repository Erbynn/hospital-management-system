/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import hospitalmanagement.DbConnect;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Chashika
 */
public class patientAdmit extends Patient {
    int Wardno,DoctorId;
    String DoctorName,AdmitDate,Disease;
    
    Connection conn;
    PreparedStatement pstt = null;
    
    
    
    public patientAdmit(int patientID,String PName,String PAge,String PGender,String PTPNumber,String PAddress,String GurdianName,int Wardno,int DoctorId,String DoctorName,String AdmitDate,String Disease,String Other  ){
        super(patientID,PName,PAge,PGender,PTPNumber,PAddress,GurdianName,Other);
        this.conn = null;
        this.Wardno = Wardno;
        this.DoctorId = DoctorId;
        this.DoctorName = DoctorName;
        this.AdmitDate = AdmitDate;
        this.Disease = Disease;
    }
    public void admitPAtient(){
        try {
            con = DbConnect.Connect();
            Statement stmt;
            stmt= con.createStatement();
        
            String sql = "INSERT into patientadmit(patientID,Name,Disease,AdmitDate,WardNo,DoctorID,DoctorName,Other)values('"+getPatientID()+"','"+ getPName() + "','"+ Disease + "','"+ AdmitDate + "','"+ Wardno + "','" + DoctorId + "','"+ DoctorName + "','" + getOther() + "')";
        
            pstt =conn.prepareStatement(sql);
            pstt.execute();
            JOptionPane.showMessageDialog(frame, "Successfully saved", "patientadmit", JOptionPane.INFORMATION_MESSAGE);
        } 
        catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(frame, ex);
        }
        
    }
}
