/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import hospitalmanagement.DbConnect;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Chashika
 */
public class ward {
    int WardId, NoOfBeds,RemainingBeds;
    int Charge;
    String WardType;
    
    Connection con = null;
    PreparedStatement pst = null;
    JFrame frame = new JFrame();
    
    public ward(int WardId,String WardType,int Charge,int NoOfBeds,int RemainingBeds){
        this.WardId = WardId;
        this.WardType = WardType;
        this.Charge = Charge;
        this.NoOfBeds = NoOfBeds;
        this.RemainingBeds = RemainingBeds;
    }
    
    public void createWard(){
        try {
            con = DbConnect.Connect();
            
            Statement stmt;
            stmt= con.createStatement();
            String sql = "INSERT INTO ward(WardID,WType,NoOfBeds,Charge,RemainingBeds)VALUES('"+WardId+"','"+WardType+"','"+NoOfBeds+"','"+Charge+"','"+RemainingBeds+"')";
            
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(frame,"Successfully Added","ward",JOptionPane.INFORMATION_MESSAGE);
        } catch(HeadlessException|SQLException ex){
            JOptionPane.showMessageDialog(frame,ex);
        
        }
    }
    
    public void show(){
        System.out.println(WardId);
        System.out.println(WardType);
        System.out.println(NoOfBeds);
        System.out.println(RemainingBeds);
        System.out.println(Charge);
    }
}
