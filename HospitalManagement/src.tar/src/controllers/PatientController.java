/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import classes.Patient;
import hospitalmanagement.DbConnect;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Chashika
 */
public class PatientController {
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    JFrame frame = new JFrame();
    
    public  void createPatient(Patient p){
        try {
            con = DbConnect.Connect();
            
            
            Statement stmt;
            stmt= con.createStatement();
            
            
            String sql = "insert into patient(id,Name,Age,Gender,TPNumber,Addresss,GurdianName,Other)values('"+p.getPatientID()+"','"+ p.getPName() + "','"+ p.getPAge() + "','"+ p.getPGender() + "','"+ p.getPTPNumber() + "','" + p.getPAddress() + "','"+ p.getGurdianName() + "','" + p.getOther() + "')";
            
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(frame, "Successfully Registered", "patient", JOptionPane.INFORMATION_MESSAGE);
            
            
        } catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(frame, ex);
          
        }
    }
    
    public void removePatient(String pid,String name){
        try {
            con = DbConnect.Connect();
        
            Statement stmt;
            stmt = con.createStatement();
        
            String sql = "DELETE from patient WHERE id='"+pid+"' OR Name='"+name+"'" ;
            
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(frame, "Successfully Deleted", "patient", JOptionPane.INFORMATION_MESSAGE);
            
        } catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(frame, ex);
        
        }
    
    }
    
    public void updatePatient(Patient p){
        try{
            con=DbConnect.Connect();
            
            Statement stmt;
            stmt = con.createStatement();
          
            String sql= "update Patient set Name='"+ p.getPName() + "',GurdianName='"+ p.getGurdianName() +  "',TPNumber='"+ p.getPTPNumber() + "',Age=" + p.getPAge() + ",Other='"+ p.getOther() + "',Gender='" + p.getPGender() +  "',Addresss='" + p.getPAddress() + "' where ID='" + p.getPatientID() + "'";

            pst=con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(frame,"Successfully updated","Record",JOptionPane.INFORMATION_MESSAGE);
            

        }catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(frame,ex);
        }  
    }
    
    public void admitPatient(){
        
    }
}
